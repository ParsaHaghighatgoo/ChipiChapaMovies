package imdb;

public enum UserRole {
    ADMIN,
    EDITOR,
    MEMBER
}

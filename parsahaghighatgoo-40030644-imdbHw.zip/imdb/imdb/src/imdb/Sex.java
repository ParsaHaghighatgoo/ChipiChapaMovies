package imdb;

public enum Sex {
    MALE,
    FEMALE,
    OTHER
}

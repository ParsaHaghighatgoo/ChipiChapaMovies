package imdb;

public enum ReportType {
    SPAM,
    VIOLENCE,
    COPYRIGHT,
    PERSONALDETAILS,
    OTHERS
}

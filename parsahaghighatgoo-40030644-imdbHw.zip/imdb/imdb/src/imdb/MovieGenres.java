package imdb;

public enum MovieGenres {
    COMEDY,
    DARMA,
    ACION,
    CARTOON ,
    HORROR
}

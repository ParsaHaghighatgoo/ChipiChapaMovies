package imdb;

public enum CastRole {
    DIRECTOR,
    ACTOR,
    WRITER
}
